Step 1 - Download Python3.8 and install all required libraries used  � 1. torch
2. numpy
3. pandas
4. torchvission
5. matplotlib
6. PIL
7. collections
8. tqdm
9. sklearn
Step 2 - Open the Notebook and press Run All. (Make sure you have all installed libraries and dataset path correct)For task 5 specifically - First we need to distribute the images in two folder SDD and DBI according to their origin.

